// ---------------------------
//  QUESTIONS (10 QUESTIONS)
// ---------------------------
const questions = [
  {
    question: "Which of the following is not a programming language?",
    options: [
      { text: "Python", correct: false },
      { text: "Java", correct: false },
      { text: "HTML", correct: false },
      { text: "Linux", correct: true }
    ]
  },
  {
    question: "What does CPU stand for?",
    options: [
      { text: "Central Pro unit", correct: false },
      { text: "Center protocol", correct: false },
      { text: "Central Processing Unit", correct: true },
      { text: "Control Unit", correct: false }
    ]
  },
  {
    question: "What does HTTP stand for?",
    options: [
      { text: "HyperText Transfer Protocol", correct: true },
      { text: "HighText Transmission Program", correct: false },
      { text: "Hyperlink Text Transmission Protocol", correct: false },
      { text: "Hyper Tool Transfer Protocol", correct: false }
    ]
  },
  {
    question: "Which data structure uses FIFO?",
    options: [
      { text: "Stack", correct: false },
      { text: "Queue", correct: true },
      { text: "Tree", correct: false },
      { text: "Graph", correct: false }
    ]
  },
  {
    question: "In a BST, which statement is true?",
    options: [
      { text: "Left > root", correct: false },
      { text: "Right < root", correct: false },
      { text: "In-order gives sorted output", correct: true },
      { text: "Root is largest", correct: false }
    ]
  },
  {
    question: "Which language is used for web client-side?",
    options: [
      { text: "Python", correct: false },
      { text: "JavaScript", correct: true },
      { text: "C++", correct: false },
      { text: "Java", correct: false }
    ]
  },
  {
    question: "Which is an operating system?",
    options: [
      { text: "Windows", correct: true },
      { text: "Chrome", correct: false },
      { text: "MS Word", correct: false },
      { text: "Python", correct: false }
    ]
  },
  {
    question: "Which memory stores data permanently?",
    options: [
      { text: "RAM", correct: false },
      { text: "Cache", correct: false },
      { text: "Hard Drive", correct: true },
      { text: "Registers", correct: false }
    ]
  },
  {
    question: "HTML heading tag?",
    options: [
      { text: "<p>", correct: false },
      { text: "<h1>", correct: true },
      { text: "<div>", correct: false },
      { text: "<head>", correct: false }
    ]
  },
  {
    question: "Which is a loop?",
    options: [
      { text: "if-else", correct: false },
      { text: "switch", correct: false },
      { text: "for", correct: true },
      { text: "break", correct: false }
    ]
  }
];

// ---------------------------
//  DOM ELEMENTS
// ---------------------------
const questionElement = document.getElementById("question");
const answerButtons = document.getElementById("answer-buttons");
const nextButton = document.getElementById("next-btn");

let currentQuestionIndex = 0;
let score = 0;

// ---------------------------
//  SHUFFLE QUESTIONS
// ---------------------------
function shuffleQuestions() {
  for (let i = questions.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [questions[i], questions[j]] = [questions[j], questions[i]];
  }
}

// ---------------------------
//  START QUIZ
// ---------------------------
function startQuiz() {
  shuffleQuestions();
  currentQuestionIndex = 0;
  score = 0;
  nextButton.textContent = "Next";
  nextButton.style.display = "none";
  showQuestion();
}

// ---------------------------
//  DISPLAY QUESTION
// ---------------------------
function showQuestion() {
  resetState();

  const current = questions[currentQuestionIndex];
  questionElement.textContent = current.question;

  current.options.forEach(option => {
    const btn = document.createElement("button");
    btn.textContent = option.text;
    btn.classList.add("btn");

    if (option.correct) btn.dataset.correct = true;

    btn.addEventListener("click", selectAnswer);
    answerButtons.appendChild(btn);
  });
}

// ---------------------------
//  CLEAR ANSWERS
// ---------------------------
function resetState() {
  nextButton.style.display = "none";
  answerButtons.innerHTML = "";
}

// ---------------------------
//  ANSWER SELECTED
// ---------------------------
function selectAnswer(e) {
  const button = e.target;
  const correct = button.dataset.correct === "true";

  button.classList.add(correct ? "correct" : "wrong");
  if (correct) score++;

  lockAnswers();
  nextButton.style.display = "block";
}

// ---------------------------
//  DISABLE ALL ANSWERS
// ---------------------------
function lockAnswers() {
  Array.from(answerButtons.children).forEach(btn => {
    if (btn.dataset.correct === "true") btn.classList.add("correct");
    btn.disabled = true;
  });
}

// ---------------------------
//  NEXT QUESTION
// ---------------------------
nextButton.addEventListener("click", () => {
  currentQuestionIndex++;
  currentQuestionIndex < questions.length ? showQuestion() : showScore();
});

// ---------------------------
//  FINAL SCORE + SAVE HIGH SCORE
// ---------------------------
function showScore() {
  resetState();

  let highScore = Number(localStorage.getItem("highScore") || 0);

  if (score > highScore) {
    localStorage.setItem("highScore", score);
    highScore = score;
  }

  questionElement.innerHTML = `
    Your Score: <b>${score}</b> / ${questions.length}<br><br>
    High Score: <b>${highScore}</b>
  `;

  nextButton.textContent = "Restart";
  nextButton.style.display = "block";
  nextButton.onclick = startQuiz;
}

// Start quiz on page load
startQuiz();

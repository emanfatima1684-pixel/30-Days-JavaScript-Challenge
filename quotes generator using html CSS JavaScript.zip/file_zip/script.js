const quotes = [
  { text: "The only way to do great work is to love what you do.", author: "Steve Jobs" },
  { text: "The unexamined life is not worth living.", author: "Socrates" },
  { text: "I think, therefore I am.", author: "René Descartes" },
  { text: "He who has a why to live can bear almost any how.", author: "Friedrich Nietzsche" },
  { text: "The only true wisdom is in knowing you know nothing.", author: "Socrates" },
  { text: "No man ever steps in the same river twice, for it's not the same river and he's not the same man.", author: "Heraclitus" },
  { text: "The greatest wealth is to live content with little.", author: "Plato" },
  { text: "What we achieve inwardly will change outer reality.", author: "Plutarch" },
  { text: "It is not that we have a short time to live, but that we waste a lot of it.", author: "Seneca" },
  { text: "We are what we repeatedly do. Excellence, then, is not an act, but a habit.", author: "Aristotle" },
  { text: "The mind is everything. What you think you become.", author: "Buddha" },
  { text: "To be yourself in a world that is constantly trying to make you something else is the greatest accomplishment.", author: "Ralph Waldo Emerson" },
  { text: "In the middle of difficulty lies opportunity.", author: "Albert Einstein" },
  { text: "The impediment to action advances action. What stands in the way becomes the way.", author: "Marcus Aurelius" },
  { text: "He who is not a good servant will not be a good master.", author: "Plato" },
  { text: "The happiness of your life depends upon the quality of your thoughts.", author: "Marcus Aurelius" },
  { text: "Man is condemned to be free; because once thrown into the world, he is responsible for everything he does.", author: "Jean-Paul Sartre" },
  { text: "The function of prayer is not to influence God, but rather to change the nature of the one who prays.", author: "Søren Kierkegaard" },
  { text: "That which does not kill us makes us stronger.", author: "Friedrich Nietzsche" },
  { text: "Know thyself.", author: "Ancient Greek Proverb" },
  { text: "The life of money-making is one undertaken under compulsion, and wealth is evidently not the good we are seeking.", author: "Aristotle" },
  { text: "One cannot step twice in the same river.", author: "Heraclitus" },
  { text: "The only thing I know is that I know nothing.", author: "Socrates" },
  { text: "Happiness is not an ideal of reason, but of imagination.", author: "Immanuel Kant" },
  { text: "A man who stands for nothing will fall for anything.", author: "Malcolm X" },
  { text: "Turn your wounds into wisdom.", author: "Oprah Winfrey" },
  { text: "Believe you can and you're halfway there.", author: "Theodore Roosevelt" },
  { text: "The best time to plant a tree was 20 years ago. The second best time is now.", author: "Chinese Proverb" },
  { text: "It does not matter how slowly you go as long as you do not stop.", author: "Confucius" },
  { text: "Everything has beauty, but not everyone sees it.", author: "Confucius" }
];

const quoteText = document.getElementById('quote');
const quoteAuthor = document.getElementById('author');
const newQuoteBtn = document.getElementById('new-quote');
const copyQuoteBtn = document.getElementById('copy-quote');
const counterDisplay = document.getElementById('counter');

let currentIndex = -1;
let quoteHistory = [];

// Function to get a new random quote
function getNewQuote() {
  let randomIndex;
  
  // Ensure we don't get the same quote twice in a row
  do {
    randomIndex = Math.floor(Math.random() * quotes.length);
  } while (randomIndex === currentIndex && quotes.length > 1);
  
  currentIndex = randomIndex;
  quoteHistory.push(randomIndex);
  
  return quotes[randomIndex];
}

// Function to display quote with animation
function displayQuote() {
  const quote = getNewQuote();
  
  // Add fade-out class
  quoteText.classList.add('fade-out');
  quoteAuthor.classList.add('fade-out');
  
  setTimeout(() => {
    // Update content
    quoteText.textContent = `"${quote.text}"`;
    quoteAuthor.textContent = `— ${quote.author}`;
    
    // Update counter
    counterDisplay.textContent = `Quote ${quoteHistory.length} of ${quotes.length}`;
    
    // Remove fade-out and add fade-in
    quoteText.classList.remove('fade-out');
    quoteAuthor.classList.remove('fade-out');
    quoteText.classList.add('fade-in');
    quoteAuthor.classList.add('fade-in');
    
    // Remove fade-in class after animation
    setTimeout(() => {
      quoteText.classList.remove('fade-in');
      quoteAuthor.classList.remove('fade-in');
    }, 500);
  }, 300);
}

// Function to copy quote to clipboard
function copyQuote() {
  const currentQuote = quoteText.textContent;
  const currentAuthor = quoteAuthor.textContent;
  const textToCopy = `${currentQuote} ${currentAuthor}`;
  
  navigator.clipboard.writeText(textToCopy).then(() => {
    showCopiedNotification();
  }).catch(err => {
    console.error('Failed to copy text: ', err);
  });
}

// Function to show copied notification
function showCopiedNotification() {
  // Remove existing notification if present
  const existingNotification = document.querySelector('.copied-notification');
  if (existingNotification) {
    existingNotification.remove();
  }
  
  // Create new notification
  const notification = document.createElement('div');
  notification.className = 'copied-notification';
  notification.textContent = '✓ Copied to clipboard!';
  document.body.appendChild(notification);
  
  // Remove notification after animation
  setTimeout(() => {
    notification.remove();
  }, 3000);
}

// Event listeners
newQuoteBtn.addEventListener('click', displayQuote);
copyQuoteBtn.addEventListener('click', copyQuote);

const shareQuoteBtn = document.getElementById('share-quote');
shareQuoteBtn.addEventListener('click', shareQuote);

// Function to share quote
function shareQuote() {
  const currentQuote = quoteText.textContent;
  const currentAuthor = quoteAuthor.textContent;
  const textToShare = `${currentQuote} ${currentAuthor}`;
  
  if (navigator.share) {
    navigator.share({
      title: 'Inspiring Quote',
      text: textToShare,
    }).catch(err => console.log('Error sharing:', err));
  } else {
    copyQuote();
    showCopiedNotification();
  }
}

// Add keyboard shortcuts
document.addEventListener('keydown', (e) => {
  if (e.code === 'Space' && e.target.tagName !== 'BUTTON') {
    e.preventDefault();
    displayQuote();
  } else if ((e.ctrlKey || e.metaKey) && e.key === 'c' && e.target.tagName !== 'BUTTON') {
    e.preventDefault();
    copyQuote();
  }
});
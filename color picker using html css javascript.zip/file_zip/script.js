const colorBox = document.getElementById("colorBox");
const colorValue = document.getElementById("colorValue");
const generateBtn = document.getElementById("generateBtn");
const colorPicker = document.getElementById("colorPicker");
const copyBtn = document.getElementById("copyBtn");

// Generate random hex color
function generateColor() {
  const randomColor = "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0");
  setColor(randomColor);
}

// Set color
function setColor(color) {
  colorBox.style.background = color;
  colorValue.textContent = color;
  colorPicker.value = color;
}

// Copy color to clipboard
copyBtn.addEventListener("click", () => {
  navigator.clipboard.writeText(colorValue.textContent);
  copyBtn.textContent = "Copied!";
  setTimeout(() => copyBtn.textContent = "Copy Color", 1000);
});

// Event listeners
generateBtn.addEventListener("click", generateColor);

colorPicker.addEventListener("input", (e) => {
  setColor(e.target.value);
});

// Initial color
setColor("#ffffff");

const inputBox = document.getElementById("input-box");
const listContainer = document.getElementById("list-container");
const addButton = document.getElementById("add-btn");

// Add new task
function addTask() {
    const task = inputBox.value.trim();
    if (task === '') {
        alert("You must write something!");
        return;
    }

    const li = document.createElement("li");
    li.textContent = task;

    const span = document.createElement("span");
    span.textContent = "×";
    span.className = "close";
    li.appendChild(span);

    listContainer.appendChild(li);

    inputBox.value = "";

    saveData();
}

// Click event: check or delete
listContainer.addEventListener("click", function (e) {

    // DELETE
    if (e.target.classList.contains("close")) {
        e.target.parentElement.remove();
        saveData();
        return;
    }

    // CHECK ONLY WHEN CLICKING THE CIRCLE AREA
    if (e.offsetX <= 40) {
        e.target.classList.toggle("checked");
        saveData();
    }
});

// Add task button
addButton.addEventListener("click", addTask);

// Enter key
inputBox.addEventListener("keypress", function (e) {
    if (e.key === "Enter") addTask();
});

// Save to localStorage
function saveData() {
    localStorage.setItem("data", listContainer.innerHTML);
}

// Load tasks
function showTask() {
    listContainer.innerHTML = localStorage.getItem("data");
}

showTask();

const notesContainer = document.querySelector(".notes-container");
const createBtn = document.querySelector("#createBtn");

createBtn.addEventListener("click", () => {
    let inputBox = document.createElement("p");
    let img = document.createElement("img");

    inputBox.className = "input-box";
    inputBox.setAttribute("contenteditable", "true");

    img.src = "IMAGES/delete.png";
    img.alt = "Delete";

    inputBox.appendChild(img);
    notesContainer.appendChild(inputBox);
});
notesContainer.addEventListener("click", function (e) {
    if (e.target.tagName === "IMG") {
        e.target.parentElement.remove();
    }
});
